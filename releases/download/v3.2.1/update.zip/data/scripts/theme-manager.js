(function() {
    const DESIGN_KEY = 'rx_design';
    const DARKMODE_KEY = 'rx_darkmode';
    const PINKMODE_KEY = 'rx_pinkmode_enabled';
    const FEAT_WEATHER_KEY = 'rx_feat_weather';
    const FEAT_LOCATION_KEY = 'rx_feat_location';
    const FEAT_LAUNCHER_KEY = 'rx_feat_launcher';
    const LAUNCHER_CONFIG_KEY = 'rx_launcher_config';
    const LAUNCHER_APPS_KEY = 'rx_launcher_apps';
    const ACCENT_KEY = 'rx_accent';
    const USERNAME_KEY = 'rx_username';

    function applySettings() {
        const isTablet = window.innerWidth >= 768;
        let design = localStorage.getItem(DESIGN_KEY);
        
        if (!design) {
             design = isTablet ? 'tablet' : 'standard';
        }
        const darkMode = localStorage.getItem(DARKMODE_KEY) === 'true';
        const pinkMode = localStorage.getItem(PINKMODE_KEY) === 'true';
        const weatherEnabled = localStorage.getItem(FEAT_WEATHER_KEY) !== 'false'; // Standard: an
        const locationEnabled = localStorage.getItem(FEAT_LOCATION_KEY) !== 'false'; // Standard: an
        const launcherEnabled = localStorage.getItem(FEAT_LAUNCHER_KEY) === 'true'; // Standard: aus
        const accent = localStorage.getItem(ACCENT_KEY) || 'blue';

        const body = document.body;
        // Alte Design-Klassen entfernen
        body.classList.remove('design-standard', 'design-list', 'design-tiles', 'design-focus', 'design-pink', 'design-tablet');
        // Neues Design setzen
        if (!body.classList.contains('no-layout-change') || design === 'pink' || design === 'tablet') {
            body.classList.add('design-' + design);
        }

        // Akzentfarbe setzen
        body.classList.remove('accent-blue', 'accent-red', 'accent-green', 'accent-orange', 'accent-purple', 'accent-pink');
        // Im Pink Mode wird die Akzentfarbe auf Pink gezwungen
        body.classList.add('accent-' + (pinkMode ? 'pink' : accent));

        // Dark mode
        if (darkMode) {
            body.classList.add('dark-mode');
        } else {
            body.classList.remove('dark-mode');
        }
        
        // Launcher Mode Class
        if (launcherEnabled) {
            body.classList.add('launcher-mode');
        } else {
            body.classList.remove('launcher-mode');
        }

        // Tablet Theme CSS Injection
        const tabletStyleId = 'rx-tablet-css';
        let tabletStyle = document.getElementById(tabletStyleId);
        
        if (design === 'tablet') {
            if (!tabletStyle) {
                tabletStyle = document.createElement('style');
                tabletStyle.id = tabletStyleId;
                tabletStyle.textContent = `
                    @media (min-width: 768px) {
                        /* Layout Container */
                        body.design-tablet .app {
                            display: grid;
                            grid-template-columns: 280px 1fr;
                            grid-template-rows: 100vh;
                            overflow: hidden;
                        }
                        
                        /* Sidebar (Header) */
                        body.design-tablet .header {
                            flex-direction: column;
                            align-items: flex-start;
                            justify-content: flex-start;
                            padding: 40px 24px;
                            background: var(--card-background);
                            border-right: 1px solid var(--border-color, rgba(128,128,128,0.1));
                            height: 100%;
                            z-index: 50;
                            box-shadow: 2px 0 10px rgba(0,0,0,0.02);
                        }
                        
                        /* Sidebar Elements */
                        body.design-tablet .header h1 {
                            font-size: 28px;
                            margin: 20px 0 8px 0;
                            line-height: 1.2;
                        }
                        body.design-tablet .header p {
                            opacity: 0.6;
                            margin-bottom: 40px;
                            font-size: 15px;
                        }
                        
                        /* Navigation Links in Sidebar */
                        body.design-tablet .header .info-icon {
                            position: static;
                            margin-top: 10px;
                            display: flex;
                            align-items: center;
                            gap: 15px;
                            width: 100%;
                            padding: 14px;
                            border-radius: 14px;
                            color: var(--text-color);
                            text-decoration: none;
                            font-weight: 600;
                            transition: all 0.2s;
                            background: transparent;
                        }
                        body.design-tablet .header .info-icon:hover {
                            background: var(--background-color);
                            transform: translateX(5px);
                        }
                        body.design-tablet .header .info-icon svg {
                            width: 24px; height: 24px;
                            stroke-width: 2.5;
                        }
                        body.design-tablet .header .info-icon::after {
                            content: attr(aria-label);
                            font-size: 16px;
                        }
                        /* Push first info-icon to bottom */
                        body.design-tablet .header .info-icon:first-of-type {
                            margin-top: auto;
                        }

                        /* Content Area */
                        body.design-tablet .content {
                            height: 100%;
                            overflow-y: auto;
                            padding: 40px 50px;
                        }
                        
                        /* Dashboard Grid Optimization */
                        body.design-tablet .dashboard-grid {
                            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
                            gap: 30px;
                        }
                        
                        /* Cards */
                        body.design-tablet .nav-card {
                            aspect-ratio: 1.4;
                            display: flex;
                            flex-direction: column;
                            justify-content: center;
                            align-items: center;
                            text-align: center;
                            padding: 30px;
                            border-radius: 24px;
                            transition: transform 0.2s, box-shadow 0.2s;
                        }
                        body.design-tablet .nav-card:hover {
                            transform: translateY(-5px);
                            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                        }
                        body.design-tablet .nav-card .icon-box {
                            width: 64px; height: 64px;
                            margin-bottom: 20px;
                            background: var(--background-color);
                            border-radius: 20px;
                        }
                        body.design-tablet .nav-card .icon-box svg {
                            width: 32px; height: 32px;
                        }
                        body.design-tablet .nav-card h3 {
                            font-size: 20px;
                            margin-bottom: 5px;
                        }
                        
                        /* Weather Card */
                        body.design-tablet .weather-card.full-width {
                            grid-column: span 2;
                            aspect-ratio: auto;
                            min-height: 200px;
                        }
                        
                        /* Back Button Handling */
                        body.design-tablet .header .back-icon {
                            margin-bottom: 20px;
                            display: inline-flex;
                            padding: 10px;
                            background: var(--background-color);
                            border-radius: 50%;
                        }
                    }
                `;
                document.head.appendChild(tabletStyle);
            }
        } else {
            if (tabletStyle) tabletStyle.remove();
        }

        // Event feuern für UI-Updates (z.B. in index.html)
        window.dispatchEvent(new CustomEvent('rx-settings-changed', { 
            detail: { design, darkMode, weatherEnabled, locationEnabled, launcherEnabled, accent: (pinkMode ? 'pink' : accent), pinkMode } 
        }));
    }

    // Expose functions globally
    window.setDesign = function(designName) {
        // 'pink' nicht als Basis-Design speichern
        if (designName !== 'pink') {
            localStorage.setItem(DESIGN_KEY, designName);
        }
        applySettings();
    };

    window.setDarkMode = function(enable) {
        localStorage.setItem(DARKMODE_KEY, enable);
        applySettings();
    };

    window.setPinkMode = function(enable) {
        localStorage.setItem(PINKMODE_KEY, enable);
        applySettings();
    };

    window.setFeature = function(feature, enable) {
        if (feature === 'weather') localStorage.setItem(FEAT_WEATHER_KEY, enable);
        if (feature === 'location') localStorage.setItem(FEAT_LOCATION_KEY, enable);
        if (feature === 'launcher') localStorage.setItem(FEAT_LAUNCHER_KEY, enable);
        applySettings();
    };

    window.setAccent = function(color) {
        localStorage.setItem(ACCENT_KEY, color);
        applySettings();
    };

    window.setUsername = function(name) {
        localStorage.setItem(USERNAME_KEY, name);
    };
    
    window.setLauncherApps = function(apps) {
        localStorage.setItem(LAUNCHER_APPS_KEY, JSON.stringify(apps));
        // Trigger update without full reload
        applySettings();
    };

    window.setLauncherConfig = function(config) {
        localStorage.setItem(LAUNCHER_CONFIG_KEY, JSON.stringify(config));
        window.dispatchEvent(new CustomEvent('rx-launcher-config-changed', { detail: config }));
    };

    window.getLauncherConfig = function() {
        const defaultDock = [
             { label: 'Fahrplan', isInternal: true, type: 'timetable', action: 'main.html' },
             { label: 'Wetter', isInternal: true, type: 'weather', action: 'wetter/index.html' },
             { label: 'Chat', isInternal: true, type: 'chat', action: 'chat.html' },
             { label: 'Apps', isInternal: true, type: 'apps', isDrawerBtn: true }
        ];
        const stored = JSON.parse(localStorage.getItem(LAUNCHER_CONFIG_KEY) || '{}');
        const isTablet = window.innerWidth >= 768;
        return {
            wallpaper: stored.wallpaper || null,
            dockApps: stored.dockApps || defaultDock,
            theme: stored.theme || 'glass',
            // Lawnchair-like Options
            gridCols: stored.gridCols || (isTablet ? 6 : 4),
            gridRows: stored.gridRows || (isTablet ? 4 : 5),
            iconSize: stored.iconSize || (isTablet ? 70 : 60),
            showLabels: stored.showLabels !== false, // Default true
            // Feature Toggles
            featTimetable: stored.featTimetable !== false,
            featWeather: stored.featWeather !== false,
            featChat: stored.featChat !== false,
            featFinder: stored.featFinder !== false,
            featSettings: stored.featSettings !== false,
            featChangelog: stored.featChangelog !== false,
            featSightings: stored.featSightings !== false
        };
    };

    window.getSettings = function() {
        return {
            design: localStorage.getItem(DESIGN_KEY) || 'standard',
            darkMode: localStorage.getItem(DARKMODE_KEY) === 'true',
            pinkMode: localStorage.getItem(PINKMODE_KEY) === 'true',
            weatherEnabled: localStorage.getItem(FEAT_WEATHER_KEY) !== 'false',
            locationEnabled: localStorage.getItem(FEAT_LOCATION_KEY) !== 'false',
            launcherEnabled: localStorage.getItem(FEAT_LAUNCHER_KEY) === 'true',
            launcherApps: JSON.parse(localStorage.getItem(LAUNCHER_APPS_KEY) || '[]'),
            accent: localStorage.getItem(ACCENT_KEY) || 'blue',
            username: localStorage.getItem(USERNAME_KEY) || ''
        };
    };

    // OTA Update Logic
    window.checkForOTAUpdates = async function() {
        const btnText = document.querySelector('#update-check-btn span:first-child');
        const originalText = btnText ? btnText.textContent : 'Nach Updates suchen';
        
        // HIER ANPASSEN: Deine GitHub Raw URL
        // Die URL muss auf eine version.json zeigen.
        // Für Plugin-Updates muss 'url' im JSON auf eine ZIP-Datei mit dem 'www'-Ordner zeigen!
        const UPDATE_API_URL = 'https://raw.githubusercontent.com/flowwebdevDE/rx.updates/main/version.json'; 
        const CURRENT_VERSION = '3.2.0'; 
        
        if(btnText) btnText.textContent = 'Prüfe...';

        try {
            // Cache-Busting
            const response = await fetch(UPDATE_API_URL + '?t=' + new Date().getTime());
            
            if (!response.ok) throw new Error('Update-Server nicht erreichbar');
            
            const data = await response.json();
            
            if (data.version > CURRENT_VERSION) {
                const performUpdate = async () => {
                    // Prüfen ob es sich um eine APK handelt (dann immer Browser nutzen)
                    const isApk = data.url && data.url.toLowerCase().endsWith('.apk');
                    
                    // Prüfen ob Plugin verfügbar ist
                    const CapacitorUpdater = (window.Capacitor && window.Capacitor.Plugins) ? window.Capacitor.Plugins.CapacitorUpdater : null;
                    
                    if (CapacitorUpdater && !isApk) {
                        if(btnText) btnText.textContent = 'Lade...';
                        try {
                            // 1. Download (erwartet ZIP)
                            const version = await CapacitorUpdater.download({
                                url: data.url,
                                version: data.version
                            });
                            
                            // 2. Installieren & Reload
                            if(btnText) btnText.textContent = 'Installiere...';
                            await CapacitorUpdater.set(version);
                            
                        } catch(err) {
                            console.error(err);
                            // Fallback anbieten
                            const msg = 'Der automatische Download ist fehlgeschlagen. Möchtest du die Datei manuell herunterladen?';
                            
                            if (window.showAppPopup) {
                                window.showAppPopup('Update fehlgeschlagen', msg, 'Im Browser öffnen', () => window.open(data.url, '_system'));
                            } else {
                                if(confirm(msg)) window.open(data.url, '_system');
                            }
                            
                            if(btnText) btnText.textContent = originalText;
                        }
                    } else {
                        // Fallback: Browser (z.B. für APK)
                        window.open(data.url, '_system');
                    }
                };

                if (window.showAppPopup) {
                    window.showAppPopup(
                        'Update verfügbar', 
                        `Version ${data.version} ist verfügbar.\n\nNeuerungen:\n${data.changelog}`,
                        'Jetzt aktualisieren',
                        performUpdate
                    );
                } else {
                    if(confirm(`Update verfügbar: ${data.version}\n\nInstallieren?`)) performUpdate();
                }
            } else {
                if (window.showAppPopup) {
                    window.showAppPopup('Auf dem neuesten Stand', `Du nutzt bereits die aktuelle Version ${CURRENT_VERSION}.`);
                }
            }
        } catch (e) {
            console.warn('OTA Check failed:', e);
            if (window.showAppPopup) {
                window.showAppPopup('Fehler', 'Konnte nicht nach Updates suchen. Bitte prüfe deine Internetverbindung.');
            }
        } finally {
            // Text nur zurücksetzen, wenn wir nicht gerade laden
            if(btnText && btnText.textContent === 'Prüfe...') btnText.textContent = originalText;
        }
    };

    // Init immediately
    applySettings();
    document.addEventListener('DOMContentLoaded', applySettings);

    // =========================================
    // PAGE TRANSITION LOGIC
    // =========================================
    document.addEventListener('DOMContentLoaded', () => {
        document.body.addEventListener('click', (e) => {
            const link = e.target.closest('a');
            // Prüfen ob es ein interner Link ist, der eine Animation benötigt
            if (link && link.href && 
                link.href.startsWith(window.location.origin) && 
                !link.target && 
                !link.getAttribute('href').startsWith('#') &&
                !link.getAttribute('href').startsWith('javascript')) {
                
                e.preventDefault();
                const container = document.querySelector('.app') || document.getElementById('main-content');
                
                if (container) {
                    container.classList.add('page-exit');
                    // Warte auf Animation (200ms)
                    setTimeout(() => {
                        window.location.href = link.href;
                    }, 200);
                } else {
                    window.location.href = link.href;
                }
            }
        });
    });

    // Fix für Safari Back-Button Cache (bfcache)
    window.addEventListener('pageshow', (event) => {
        if (event.persisted) {
            const container = document.querySelector('.app') || document.getElementById('main-content');
            if (container) container.classList.remove('page-exit');
        }
    });

    // Global Haptics (Taktiles Feedback)
    document.addEventListener('click', (e) => {
        // Prüfen, ob ein interaktives Element geklickt wurde
        if (e.target.closest('a, button, .btn, .switch, .theme-btn, .card, .ls-item, .ls-seg-opt, .ls-close-btn, .ls-action, .launcher-item')) {
            if (navigator.vibrate) navigator.vibrate(5); // Sehr kurzes Feedback
        }
    });

    // Statusbar auf OLED Schwarz zwingen (auch bei Overlay)
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.StatusBar) {
        window.Capacitor.Plugins.StatusBar.setBackgroundColor({ color: '#000000' });
        window.Capacitor.Plugins.StatusBar.setOverlaysWebView({ overlay: true });
    }
})();